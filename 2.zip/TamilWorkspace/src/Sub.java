class Super {
   void Sample() {
      System.out.println("method of super class");
   }
}

public class Sub extends Super {
   void Sample() {
      System.out.println("method of sub class");
   }
   
   /*public static void main(String args[]) {
      Super obj =(Super) new Sub(); obj.Sample();
   }
}*/

public static void main(String args[]) {
    Super obj = new Sub();//upcast
    obj.Sample();
    Sub sub = (Sub) obj;//dow
    sub.Sample();
 }
}
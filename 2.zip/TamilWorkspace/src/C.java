/*
public class Vowel {
	private char var;
	public static void main(String[] args) {
		char var1='a';
		char var2=var1;
		var2='e';
		Vowel obj1=new Vowel();
		Vowel obj2=obj1;
		obj1.var='i';
		obj2.var='o';
		System.out.println(var1+" "+var2+" "+obj1.var+" "+obj2.var);
	}

}
*/

class A{
	public void test() {
		System.out.println("A");
	}
	
}
class B extends A{
	public void test() {
		System.out.println("B");
	}
	
	
}
class C extends A{
	public void test() {
		System.out.println("C");
	}
	
	public static void main(String[] args) {
		A b1=new A();
		
		A b2=new C();
		
		b1=(A)b2; //upcasting
		
	
		A b3=(B) b2;
		
	
		A b4=(B) b2;
		
		b1.test();
		b3.test();
	}
	
}
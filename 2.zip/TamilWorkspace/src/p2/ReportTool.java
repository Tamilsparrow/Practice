package p2;
interface Export{
	void ex();
}
class Tool implements Export{

	@Override
	protected void ex() {
		System.out.println("fhsdjk");
		
	}
	
}
 class ReportTool extends Tool implements Export{
	 
	public void ex() {
		System.out.println("fsfds");
	}
	public static void main(String[] args) {
		Tool a=new ReportTool();
		Tool b=new Tool();
		callEx(a);
		callEx(b);
	}
	public static void callEx(Export e) {
		// TODO Auto-generated method stub
		e.ex();
	}
	

}

package p2;
class Planet{
	public int amount;
	public Planet() {
		amount=100;
	}
}

public class Earth {
public static void main(String[] args) {
	Planet t=new Planet();
System.out.println(t.amount==100);
}
}

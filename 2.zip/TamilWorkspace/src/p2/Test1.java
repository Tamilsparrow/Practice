package p2;

import java.util.ArrayList;

public class Test1 {
public static void main(String[] args) {
	ArrayList<Integer> points=new ArrayList<>();
	points.add(1);
	points.add(2);
	points.add(3);
	points.add(4);
	//points.add(null);
	//points.remove(2);
	points.remove(null);
	System.out.println(points);
	String ta="a";
	 ta=ta.concat("b");
	 String tb="c";
	 ta=ta.concat(tb);
	 ta.replace("c", "d");
	 ta=ta.concat(tb);
	 System.out.println(ta);
	 
	 
	 int[] data= {2010,2013,2014,2015,2014};
	 int i=0;
	 int key=2014;
	 for(int e:data) {
		 if(e!=key) {
			 continue:
				 i++;
		 }
	 }
	
	 System.out.println(i);
	
}
}

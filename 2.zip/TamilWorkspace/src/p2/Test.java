package p2;

import p1.Acc;

public class Test extends Acc {
	
public static void main(String[] args) {
	Acc obj=new Test();
	obj.s=2;
	System.out.println(obj.s);

	
	System.out.println("*******************");
	String s="Java Duke";
	int len=s.trim().length();
	String s1=s.trim();
	System.out.println(len+" "+s1);
	System.out.println(args[0]+" "+args[1]+" "+args[2]+" "+args[3]);
}
}

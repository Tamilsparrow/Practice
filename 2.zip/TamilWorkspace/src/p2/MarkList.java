package p2;

public class MarkList {
	int num;
	
	public static void gracemarks(MarkList ob) {
		System.out.println(ob.num);
		ob.num+=10;
	}
	public static void main(String[] args) {
		MarkList m1=new MarkList();
		MarkList m2=m1;
		MarkList m3=null;
		
		gracemarks(m1);
		m2.num=60;
		System.out.println(m1.num);
		/*Boolean a=new Boolean(Boolean.valueOf(args[0]));
		Boolean b=new Boolean(args[1]);
		System.out.println(a+" "+b);*/
		System.out.println(m3 instanceof MarkList);
		
		
	}

}

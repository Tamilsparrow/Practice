package p2;

import java.util.ArrayList;

public class Test2 {
public static void main(String[] args) {
	/*String[][] chs=new String[2][];
	chs[0]=new String[2];
	chs[1]=new String[3];
	int i=97;
	for(int a=0;a<chs.length;a++) {
		for(int b=0;b<chs.length;b++) {
			chs[a][b]=""+i;
			i++;
		}
	}
	for(String[] ca:chs) {
		for(String c:ca) {
			System.out.print(" "+c);
		}
		System.out.println();
	}*/
	
	/*String[] names= {"Thomas","Peter","Joseph"};
	String[] pws=new String[3];
	int idx=0;
	try {
	for(String n:names) {
	pws[idx]=n.substring(2, 6);
	idx++;
	}
	}catch(Exception e) {
		System.out.println("invalid name");
	}
	for(String s:pws) {
		System.out.println(s);
	}*/
	
	String stuff="TV";
	String res=null;
	// stuff.equals("TV") ? (res= "Walter") : (stuff.equals ("Movie") ? res = "White" : res = "No Result");
	// res = stuff.equals ("TV") ? "Walter" else stuff.equals ("Movie")? "White" : "No Result";
	 res = stuff.equals ("TV") ? stuff.equals ("Movie")? "Walter" : "White" : "No Result";
	 res = stuff.equals ("TV")? "Walter" : stuff.equals ("Movie")? "White" : "No Result";
	 System.out.println(res);
	 
	 /*ArrayList<String> list=new ArrayList<>();
	 try {
		 while(true) {
			 list.add("string");
		 }
	 }catch (RuntimeException e) {
		// TODO: handle exception
		 System.out.println("run");
	}catch (Exception e) {
		// TODO: handle exception
		System.out.println(e);
	}
	System.out.println("end");*/
	 int[] numbers;
	 numbers=new int[2];
	 numbers[0]=10;
	 numbers[1]=20;
	 numbers=new int[4];
	 numbers[2]=10;
	 numbers[3]=20;
	 for(int n:numbers)
	 System.out.println(n);
}
}

import java.io.IOException;

class X{
	public void print() throws IOException {
		
			throw new IOException();
		
	}
}
public class Atest1 {
	public static void main(String[] args) throws Exception {
		/*String str1="Java";
		String str2=new String("java");
		String str3=str2;
		System.out.println(str1.hashCode()+" "+str2.hashCode()+" "+str3.hashCode());
		if(str1==str3) {
			System.out.println("equal1");
		}else {
			System.out.println("fasda");
		}*/
		X n =new X();
		
			n.print();
		
	}

}

public  class Toy{
	public static void main(String[] args) {
		
		try {
			int num=10;
			int div=0;
			int ans=num/div;
			
		}catch (ArithmeticException e) {
			// TODO: handle exception
			ans=0;
		}
		
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("exception");
		}
		
		System.out.println(ans);
	}
 }
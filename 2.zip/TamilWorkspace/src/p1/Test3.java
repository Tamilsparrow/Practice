package p1;
class Mystring{
	String msg;
	public Mystring(String msg) {
		// TODO Auto-generated constructor stub
		this.msg=msg;
	}
}
public class Test3 {
	public static void main(String[] args) {
		System.out.println("Hello"+new StringBuilder("Tamil"));
		System.out.println("Hello"+new Mystring("Tamil"));
		int n1[]=new int[3];
		int n2[]= {1,2,3,4,5};
		n1=n2;
		for(int i:n1) {
			System.out.println(i);
		}
	}

}

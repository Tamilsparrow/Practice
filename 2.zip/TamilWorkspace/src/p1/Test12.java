package p1;
class Cd{
	int r;
	Cd(int r){
		this.r=r;
	}
}
class Dvd extends Cd{
int c;
Dvd(int r){
	super(r);
}
	Dvd(int r,int c){
		super(r);
		this.c=c;
		
	}
	
}

public class Test12 {
	public static void main(String[] args) {
		Dvd d=new Dvd(10, 20);
	}

}

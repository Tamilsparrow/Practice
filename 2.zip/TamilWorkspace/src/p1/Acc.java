package p1;



public class Acc {
	int p;
	private int q;
	protected int r;
	public int s;

}

 class Test1 extends Acc {
	
public static void main(String[] args) {
	Acc obj=new Test1();
	obj.r=2;
	obj.s=3;
	System.out.println(obj.s);
	
}
}
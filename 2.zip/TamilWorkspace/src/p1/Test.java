package p1;

import java.util.ArrayList;
import java.util.List;

class Student {
	String name;
	public Student(String name) {
		// TODO Auto-generated constructor stub
		this.name=name;
	}
}

public class Test {
	public static void main(String[] args) {
		/*Student[] s=new Student[3];
		s[1]=new Student("Tamil");
		s[2]=new Student("selvan");
		for(Student ss:s) {
			System.out.println(ss.name);*/
		List<String> c=new ArrayList<String>();
		c.add("green");//0
		c.add("red");//1
		c.add("blue");//
		c.add("yellow");//2
		c.remove(2);
		c.add(3,"cyan");//3
		System.out.println(c);
		
		Student s1=new Student("name");
		Student s2=new Student("name");
		Student s3=new Student("name");
		s1=s3;
		s3=s2;
		s2=null;
		System.out.println(s1+" "+s2+" "+s3);
		int x=100;
		int a=x++;
		int b=++x;
		int e=x++;
		int d=(a<b) ? (a<e) ? a:e : (b<e) ? b :e;
		System.out.println(d+" "+a+" "+b+" "+e);
		
		float var1=(12_345.01>=123_45.01) ? 12_456: 124_56.02f;
		float var2=var1+1024;
		System.out.println(var2);
		
	}
	

}

package p1;

public class Person {
	 String name;
	int age=25;
	public Person() {
		// TODO Auto-generated constructor stub
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}

   public Person(String name){
	//this();
		setName(name);
	}
public String show() {
	return name+" "+age;
}
public Person(String name,int age) {
	// TODO Auto-generated constructor stub
	Person(name);
	setAge(age);
}
 

public static void main(String[] args) {
	Person p1=new Person("jessie");
	Person p2=new Person("walter", 45);
	System.out.println(p1.show());
	System.out.println(p2.show());
}

}

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

class Patient{
	String name;
	public Patient(String name) {
		this.name=name;
	}
}
public class Test {
	public static void main(String[] args) {
		
	
	List ps=new ArrayList();
	Patient p1=new Patient("Mike");
	ps.add(p1);
	Patient p=new Patient("Mike");
	int f=ps.indexOf(p1);
	if(f>=0) {
		System.out.println("Mike found");
	}

	
	String str=" ";
	str=str.trim();
	System.out.println(str.equals("")+" "+str.isEmpty());
	
	String[] arr= {"A", "B", "C", "D"};
	String[][] arr1=new String[][]{{"a","b","c"},{"a","b","c","d"}};
	System.out.println(arr1.length+" "+arr1[1].length);
	for(int i=0;i<arr1.length;i++) {
		for(int j=0;j<arr1[i].length;j++) {
		System.out.print(arr1[i][j]+" ");
		if(arr1[i].equals("C")) {
			
		}}

	}
	
	LocalDate date=LocalDate.of(2019, 1, 32)	;
	date.plusDays(10);
	System.out.println(date);
}
	}

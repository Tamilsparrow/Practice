
public class Customer {
	Account a=new Account();
	public void useee(double kwh) {
		use()
	}

}

class Account{
	private double kwh;
	private double rate=0.07;
	private double bill;
	private double use(double kwh) {
		return kwh;
	}
}

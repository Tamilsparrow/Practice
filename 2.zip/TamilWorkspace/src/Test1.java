interface Downloadable{
	public void download();
}
interface Readable extends Downloadable{
	public void read();
}
abstract class Book implements Readable{
	public void read() {
		System.out.println("read");
	}
}

  class Ebook extends Book{

	
	public void read() {
		System.out.println("readsss");
	}

	

	

	
	
	
}
public class Test1 {
Book b1=new Ebook() ;
b1.read();
}

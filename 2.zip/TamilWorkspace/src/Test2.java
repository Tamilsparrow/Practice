class Vehicle{
	public void m() {
		System.out.println("d");
	}
}
 class Car extends Vehicle{
	 public void m() {
		 System.out.println("e");
	 }
	 
	
}
 class Auto extends Car{
	 public void m() {
		 System.out.println("f");
	 }
	
 }
 
 
class Test2 {
	public static void main(String[] args) {
		Vehicle t1=new Car();
		Vehicle t2=new Auto();
		Vehicle t3=new Car();
		t1= (Vehicle)t3;
		Vehicle t4=(Vehicle)t3;
		t4.m();
	
	}

}

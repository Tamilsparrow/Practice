
public class Init {
	int x,y;
	 public Init(int x,int y) {
		// TODO Auto-generated constructor stub
       initial(x,y);
	 }
	private void initial(int x,int y) {
		// TODO Auto-generated method stub
		this.x=x*y;
		System.out.println(this.x+" "+x);
		this.y=x*y;
	}
	public static void main(String[] args) {
		int x=3,y=5;
		Init o=new Init(x, y);
		//System.out.println(o.x+" "+o.y);
		
	}

}

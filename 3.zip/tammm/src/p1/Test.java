package p1;

public class Test {
	public static int stvar=100;
	public int var=200;
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return var+":"+stvar;
	}
public static void main(String[] args) {
	Test t1=new Test();
	t1.var=300;
	System.out.println(t1);
	Test t2=new Test();
	t2.stvar=300;
	System.out.println(t1);
	System.out.println(t2);
	
 Integer key=new Integer("1");
	switch (key) {
	case 1:
		System.out.println("1");
		break;
	case 2:
		System.out.println("2");
		break;
	case 3:
		System.out.println("3");
		break;

	default:System.out.println("default");
		break;
	}
	int i=10;
	int j=20;
	int k= j+=i/5;
	System.out.println(i+" "+j+" "+" "+k);
}
}

package p1.p2;

import p1.A;

public class B {
 public void doS() {
	 A a=new A();
 }
}

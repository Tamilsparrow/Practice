import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class App {
	String mystr="7007";
	int mynum=10;
	public void dostuff(String str) {
		//int mynum=0;
		
		
		try {
			String mystr = str;
			int mynum=Integer.parseInt(str);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(mystr+" "+mynum);
		
	}
	public static void main(String[] args) {
		App p=new App();
		p.dostuff("9009");
		
		int[] arr= {1,2,3,4};
		int i=0;
		do {
			System.out.println(arr[i]+" ");
			i++;
		}while(i<arr.length-1);
		LocalDate d=LocalDate.now();
		LocalDate d1=LocalDate.of(2019, 6, 19);
		LocalDate d2=LocalDate.parse("2019-06-19", DateTimeFormatter.ISO_DATE);
		System.out.println(d+" "+d1+" "+d2);
		
		String[] arrl={"Hi","How","are","you"};
		List<String> list=new ArrayList<>(Arrays.asList(arrl));
		if(list.removeIf((String s)-> ( return s.length()<=2;))){
			
		}
	}

}

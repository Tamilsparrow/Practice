package p3;

class Test{
	public static void main(String[] args) {
		Employee e1=new Employee();
		Employee e2=new Employee("Tamil", 21);
		Employee e3=new Employee("Tamil", 21, 2000);
		e1.printdetails();
		e2.printdetails();
		e3.printdetails();
		
	}
}

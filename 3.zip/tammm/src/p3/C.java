package p3;

import p1.A;
import p1.p2.*;

public class C {
	public static void main(String[] args) {
		/*A a=new A();
		B b=new B(); 
		short s1=200;
		Integer s2=400;
		Long s3=(long)s1+s2;
		String s4=(String)(s3*s2);//n2
		System.out.println(s4);*/
		
		/*int i=100;
		float f=100.101F;
		double d=123;
		
		i=f;
		f=i;
		d=f;*/
		
		StringBuilder sb1=new StringBuilder("Duke");
	
		
		String str1=sb1.toString();
		String str2=sb1.toString();
		//String str2=str1;
		System.out.println(str1+" "+str2+" "+str1.hashCode()+" "+str2.hashCode());
		System.out.println(str1==str2);
		
		/*System.out.println("Trust a"+1+2);
		System.out.println("Trust a"+(1)+(2));
		
		int n[][]= {{1,3},{2,4}};
		for(int i=n.length-1;i>=0;i--) {
			for(int y:n[i]) {
				System.out.println(y);
			}
		}*/
	}

}


public class Stick {
static int i;
void display() {
//	System.out.println(i);
}
public static void main(String[] args) {
	int a;
	//System.out.println(i+" "+a);
	System.out.println(new StringBuilder("Tamil") );
	System.out.println(new String("siva"));
	Byte b=100;
	Short s1=200;
	Integer s2=400;
	Long i=
	Long s3=(long) s1+s2;
	String s4=(String)(s3*s2);
}

}

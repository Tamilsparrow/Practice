interface Exportable{
	void export();
}
class Tool implements Exportable{

	
	protected void export() {
		// TODO Auto-generated method stub
		System.out.println("Tool");
	}
	
}
public class ReportTool extends Tool implements Exportable{

	
	public void export() {
		// TODO Auto-generated method stub
		
	}
	public static void main(String[] args) {
		Tool a=new ReportTool();
		
	}
	

}

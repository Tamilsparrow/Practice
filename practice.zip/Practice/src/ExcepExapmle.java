import java.io.IOException;

class X{
	public void print() throws IOException  {
		throw new IOException();
	}
}
public class ExcepExapmle {
	public static void main(String[] args) throws IOException {
		X ob=new X();
		ob.print();
	}

}

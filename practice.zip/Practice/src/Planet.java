
abstract class Planet {
protected  void revolve() {
	
}
abstract  void rotate();
}
class Earth extends Planet{
	 public void revolve() {
			
		}

	@Override
	protected void rotate() {
		// TODO Auto-generated method stub
		
	}
	
}
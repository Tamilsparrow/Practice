package p1;

public class Acc {
	int p=0;
	 private int q=0;
	    protected int r=0;
	    public int s=0;
	public static void main(String[] args) {
		
	   
	}
	
}
/*class C extends Acc{
	public static void main(String[] args) {
		Acc t=new C();
		t.r=0;
	}
}*/

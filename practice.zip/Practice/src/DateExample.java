import java.time.LocalDate;

public class DateExample {
	public static void main(String[] args) {
		LocalDate d=LocalDate.of(2019, 6, 32);
		d.plusDays(10);
		System.out.println(d);
	}

}

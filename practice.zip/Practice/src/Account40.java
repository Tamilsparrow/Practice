class CheckingAccount{
	public int amount;
	public CheckingAccount(int amount) {
		// TODO Auto-generated constructor stub
		this.amount=amount;
		
		
	}
	/*public CheckingAccount() {
		// TODO Auto-generated constructor stub
		this.amount=100;
		/System.out.println(amount+" * "+this.amount);
	}*/
	public int getAmount() {
		return amount;
	}
	public void changeAmount(int x) {
		amount+=x;
	}
	
}
public class Account40 {
	public static void main(String[] args) {
		
		CheckingAccount acct=new CheckingAccount((int)(Math.random()*1000));
		//acct.amount=0;
		//acct.changeAmount(-acct.getAmount());
		//acct.changeAmount(-acct.amount);
		
		System.out.println(acct.getAmount());
		
	}

}

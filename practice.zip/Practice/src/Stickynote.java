import java.util.ArrayList;
interface India{
	 public void t();
}
abstract class A implements India{
	protected void s() {
		System.out.println("t+s");
	}
	
}


/*abstract public class Stickynote extends A{
	public static void main(String[] args) {
		A a=new A();
		a.s();
		int x=100;
		int a=x++;
		int b=++x;
		int c=x++;
		int d= (a<b) ? (a<c) ? a : (b<c) ? b :c;
		
		try {
			int num=0;
		}catch (Exception e) {
			// TODO: handle exception
			num=0;
		}
		System.out.println(num);
		ArrayList<Integer> list=new ArrayList<>();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(null);
		list.remove(2);
		//list.remove(null);
		System.out.println(list);
	}

}
*/
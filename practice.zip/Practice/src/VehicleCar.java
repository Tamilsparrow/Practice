class Vehicle{
	int x;
	public Vehicle() {
	this(10);
		// TODO Auto-generated constructor stub
	}
	public Vehicle(int x) {
		// TODO Auto-generated constructor stub
		this.x=x;
	}
}
class Car extends Vehicle{
	int y;
	public Car() {
		
	this(20);
	super();
		// TODO Auto-generated constructor stub
	}
	public Car(int y) {
		this.y=y;
		// TODO Auto-generated constructor stub
	}
}
public class VehicleCar {
	public static void main(String[] args) {
		Vehicle y=new Car();
		System.out.println(y);
	}

}

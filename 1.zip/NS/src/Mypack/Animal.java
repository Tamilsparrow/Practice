package Mypack;

public class Animal {
String type="canine";
int maxspeed=60;
 Animal() {
	// TODO Auto-generated constructor stub
}
 Animal(String type,int maxspeed){
	 this.type=type;
	 this.maxspeed=maxspeed;
 }

}


package Mypack;
class Myexception extends RuntimeException{
	
}
public class Test {
	char c;
	boolean b;
	float f;
    String s;
    double d;

    void findall() {
    	System.out.println("c:"+c+"b: "+b+" "+"f: "+f+" "+"s: "+s+" "+"d: "+d);
    }
public static void main(String[] args) {
	Test t=new Test();
	t.findall();
	
	boolean opt=true;
	switch(opt) {
	case "true":
		System.out.println("tt");
		break;
	}
	/*String str="Hello World ";
	String str1=str.trim();
	System.out.println(str1.indexOf(" "));
	System.out.println(str1+str);
	*/
	/*String strs[]=new String[2];
	int i=0;
	for(String s:strs) {
		strs[i].concat("elsemnt "+i);
		System.out.println(strs[i]);
	}
	for(int x=0;x<strs.length;x++) {
		System.out.print(strs[x]+" ");
	}*/
	
	StringBuilder sb=new StringBuilder("Tamil");
	sb.delete(0, sb.length());
	System.out.println(sb.toString());
	/*try {
		method();
	}catch (Myexception e) {
		// TODO: handle exception
		System.out.println("a");
	}*/
	
	
}

/*private static void method() {
	// TODO Auto-generated method stub
	try {
		throw Math.random() >0.5 ? new Myexception():new RuntimeException(); 
	} catch (RuntimeException e) {
		// TODO: handle exception
		System.out.println("B");
		StringBuilder sb=new StringBuilder(5);
		System.out.println(sb.toString()+" "+sb.capacity());
	}
}*/

}

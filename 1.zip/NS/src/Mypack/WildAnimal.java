package Mypack;

public class WildAnimal {
	String bounds,type;
	int maxspeed;
	public WildAnimal(String bounds) {
		// TODO Auto-generated constructor stub
		super();
	}
	public WildAnimal(String type,int maxspeed,String bound) {
		// TODO Auto-generated constructor stub
		this.bounds=bounds;
		
	}
	public static void main(String[] args) {
		WildAnimal wolf=new WildAnimal("Long");
		WildAnimal tiger=new WildAnimal("Feline", 8,"Short");
		System.out.println(wolf.type+" "+wolf.maxspeed+" "+wolf.bounds);
		System.out.println(tiger.type+" "+tiger.maxspeed+" "+tiger.bounds);
	}

}

package Mypack;

import java.time.LocalDate;
import java.util.Formatter;

import javax.swing.text.DateFormatter;

public class Excep {
	public void read(int no) throws Exception{
		System.out.println("read");
	}
	public void write(int no) throws RuntimeException{
		System.out.println("readerite");
	}
public static void main(String[] args)  {
	Excep e=new Excep();
	int id=123;
	e.read(id);
	e.write(id);
	LocalDate date=LocalDate.parse("2019-6-31");
}
}
